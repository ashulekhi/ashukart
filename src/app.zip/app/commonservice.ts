import { Injectable } from "@angular/core";

@Injectable()
export class CommonService{
    username:''
    password:''

    showservicedemo(){
        
    }
}
import { Component } from "@angular/core";
import {HttpClient} from "@angular/common/http";

@Component({
    selector:'app-signup',
    templateUrl:'./signup.component.html',
    styleUrls:[]
})
export class SignupComponent{
    constructor(private http : HttpClient){

    }
user ={}
signup(){
   let url = "https://learningmeanwithashu.herokuapp.com/api/register"
   console.log("user details" , this.user); 
   this.http.post(url,this.user).subscribe((data)=>{
       console.log("data" , data);
   },(error)=>{
       console.log("error is", error);
   })
}
}